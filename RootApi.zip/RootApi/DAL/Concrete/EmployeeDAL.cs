﻿using Microsoft.EntityFrameworkCore;
using RootApi.DAL.Abstract;
using RootApi.DAL.Entities;
using RootApi.DAL.SQLContext;

namespace RootApi.DAL.Concrete
{
    public class EmployeeDAL : IEmployeeDAL
    {
        private readonly SqlContextDal _sqlContextDal;
        public EmployeeDAL(SqlContextDal sqlContextDal)
        {
            _sqlContextDal = sqlContextDal;
        }

        public void Add(Employee employee)
        {
            _sqlContextDal.Add(employee);
         //   throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            _sqlContextDal.Remove(id);
            throw new NotImplementedException();
        }

        public void Edit(Employee employee)
        {
            _sqlContextDal.Update(employee);
        }

        public IEnumerable<Employee> GetAll()
        {
            return _sqlContextDal.Employee.ToList();
        }

        public Employee GetById(int id)
        {
            var user = _sqlContextDal.Employee.FirstOrDefault(x => x.Emp_id == id);
            if (user != null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }
    }
}
