﻿using Microsoft.EntityFrameworkCore;
using RootApi.DAL.Abstract;
using RootApi.DAL.Entities;
using RootApi.DAL.SQLContext;

namespace RootApi.DAL.Concrete
{
    public class UserDAL : IUserDAL
    {
        private readonly SqlContextDal _sqlContextDal;
        public UserDAL(SqlContextDal sqlContextDal)
        {
            _sqlContextDal = sqlContextDal;
        }

        public void Add(UserMaster employee)
        {
            _sqlContextDal.Add(employee);
         //   throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            _sqlContextDal.Remove(id);
            throw new NotImplementedException();
        }

        public void Edit(UserMaster employee)
        {
            _sqlContextDal.Update(employee);
        }

        public IEnumerable<UserMaster> GetAll()
        {
            return _sqlContextDal.UserMaster.ToList();
        }

        public UserMaster GetById(int id)
        {
            var user = _sqlContextDal.UserMaster.FirstOrDefault(x => x.User_ID == id);
            if (user != null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

    }
}
