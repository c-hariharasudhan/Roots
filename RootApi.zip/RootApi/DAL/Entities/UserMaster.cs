﻿using System.ComponentModel.DataAnnotations;

namespace RootApi.DAL.Entities
{
    public class UserMaster
    {
        [Key]
        public int User_ID { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? IsActive { get; set; }
        public string? PasswordHash { get; set; }
        public string? EmailAddress { get; set; }
    }
}
