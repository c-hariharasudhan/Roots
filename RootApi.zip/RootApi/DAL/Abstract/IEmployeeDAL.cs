﻿using RootApi.DAL.Entities;

namespace RootApi.DAL.Abstract
{
    public interface IEmployeeDAL
    {
        Employee GetById(int id);
        IEnumerable<Employee> GetAll();
        void Add(Employee employee);
        void Edit(Employee employee);
        void Delete(int id);
    }
}
