﻿using RootApi.DAL.Entities;

namespace RootApi.DAL.Abstract
{
    public interface IUserDAL
    {
        UserMaster GetById(int id);
        IEnumerable<UserMaster> GetAll();
        void Add(UserMaster userMaster);
        void Edit(UserMaster userMaster);
        void Delete(int id);
    }
}
