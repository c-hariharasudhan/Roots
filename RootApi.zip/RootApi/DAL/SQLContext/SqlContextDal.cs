﻿using Microsoft.EntityFrameworkCore;
using RootApi.DAL.Entities;
using System.Collections.Generic;

namespace RootApi.DAL.SQLContext
{
    public class SqlContextDal : DbContext
    {
        public SqlContextDal(DbContextOptions<SqlContextDal> options)
              : base(options)
        {
        }

        public DbSet<UserMaster> UserMaster { get; set; }
        public DbSet<Employee> Employee { get; set; }
    }
}
