﻿using DataLayer.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Context
{
    public class SqlDbContext : DbContext
    {
        public SqlDbContext(DbContextOptions<SqlDbContext> options)
              : base(options)
        {
        }

        public DbSet<UserMaster> UserMaster { get; set; }
        // public DbSet<Employee> Employee { get; set; }
    }
}
