﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DataLayer.Repository
{
    public interface IuserMasterRepository
    {
        Task Add(UserMaster userMaster);
        Task<UserMaster> Get(int id);
        Task<IEnumerable<UserMaster>> GetAll();
        Task Update(UserMaster userMaster);
        Task Delete(int id);
    }
}
