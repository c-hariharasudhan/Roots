﻿using DataLayer.Context;
using DataLayer.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DataLayer.Repository
{
    public class UserMasterRepository : IuserMasterRepository
    {
        private SqlDbContext _SqlDbContext;
        private readonly ILogger<UserMasterRepository> _logger;

        public UserMasterRepository(SqlDbContext SqlDbContext, ILogger<UserMasterRepository> logger)
        {
            _SqlDbContext = SqlDbContext;
             _logger = logger;
        }

        public async Task Add(UserMaster userMaster)
        {
            _logger.LogInformation("UserMaster Add Action", userMaster);
             await _SqlDbContext.AddAsync(userMaster);
             await _SqlDbContext.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var entity = _SqlDbContext.UserMaster.FirstOrDefault(a => a.User_ID == id);
            _SqlDbContext.Remove(entity);
            await _SqlDbContext.SaveChangesAsync();
        }

        public async Task<UserMaster> Get(int id)
        {
            return  await _SqlDbContext.UserMaster.FindAsync(id);
        }

        public async Task<IEnumerable<UserMaster>> GetAll()
        {
            return await _SqlDbContext.UserMaster.ToListAsync();
        }

        public async Task Update(UserMaster userMaster)
        {
            _SqlDbContext.Update(userMaster);
            await _SqlDbContext.SaveChangesAsync();
        }
    }
}
