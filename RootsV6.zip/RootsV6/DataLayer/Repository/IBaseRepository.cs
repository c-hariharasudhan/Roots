﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Repository
{
    internal class IBaseRepository
    {
    }
}
