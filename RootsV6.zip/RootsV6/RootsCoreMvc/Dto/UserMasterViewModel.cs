﻿using System;

namespace RootsCoreMvc.Dto
{
    public class UserMasterViewModel
    {
        public int Emp_id { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string IsActive { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public DateTime Joining_Date { get; set; }
        public string Manager_id { get; set; }
        public string Dept_id { get; set; }
        public string Salary { get; set; }
        public string Designation { get; set; }
    }
}
