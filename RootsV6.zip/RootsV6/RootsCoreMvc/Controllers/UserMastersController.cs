﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataLayer.Context;
using DataLayer.Entities;
using DataLayer.Repository;
using BusinessLogic.Logics;

namespace RootsCoreMvc.Controllers
{
    //public class UserMastersController : Controller
    //{
    //    private readonly SqlDbContext _context;

    //    public UserMastersController(SqlDbContext context)
    //    {
    //        _context = context;
    //    }

    //    // GET: UserMasters
    //    public async Task<IActionResult> Index()
    //    {
    //        return View(await _context.UserMaster.ToListAsync());
    //    }

    //    // GET: UserMasters/Details/5
    //    public async Task<IActionResult> Details(int? id)
    //    {
    //        if (id == null)
    //        {
    //            return NotFound();
    //        }

    //        var userMaster = await _context.UserMaster
    //            .FirstOrDefaultAsync(m => m.User_ID == id);
    //        if (userMaster == null)
    //        {
    //            return NotFound();
    //        }

    //        return View(userMaster);
    //    }

    //    // GET: UserMasters/Create
    //    public IActionResult Create()
    //    {
    //        return View();
    //    }

    //    // POST: UserMasters/Create
    //    // To protect from overposting attacks, enable the specific properties you want to bind to, for 
    //    // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    //    [HttpPost]
    //    [ValidateAntiForgeryToken]
    //    public async Task<IActionResult> Create([Bind("User_ID,FirstName,LastName,IsActive,PasswordHash,EmailAddress")] UserMaster userMaster)
    //    {
    //        if (ModelState.IsValid)
    //        {
    //            _context.Add(userMaster);
    //            await _context.SaveChangesAsync();
    //            return RedirectToAction(nameof(Index));
    //        }
    //        return View(userMaster);
    //    }

    //    // GET: UserMasters/Edit/5
    //    public async Task<IActionResult> Edit(int? id)
    //    {
    //        if (id == null)
    //        {
    //            return NotFound();
    //        }

    //        var userMaster = await _context.UserMaster.FindAsync(id);
    //        if (userMaster == null)
    //        {
    //            return NotFound();
    //        }
    //        return View(userMaster);
    //    }

    //    // POST: UserMasters/Edit/5
    //    // To protect from overposting attacks, enable the specific properties you want to bind to, for 
    //    // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    //    [HttpPost]
    //    [ValidateAntiForgeryToken]
    //    public async Task<IActionResult> Edit(int id, [Bind("User_ID,FirstName,LastName,IsActive,PasswordHash,EmailAddress")] UserMaster userMaster)
    //    {
    //        if (id != userMaster.User_ID)
    //        {
    //            return NotFound();
    //        }

    //        if (ModelState.IsValid)
    //        {
    //            try
    //            {
    //                _context.Update(userMaster);
    //                await _context.SaveChangesAsync();
    //            }
    //            catch (DbUpdateConcurrencyException)
    //            {
    //                if (!UserMasterExists(userMaster.User_ID))
    //                {
    //                    return NotFound();
    //                }
    //                else
    //                {
    //                    throw;
    //                }
    //            }
    //            return RedirectToAction(nameof(Index));
    //        }
    //        return View(userMaster);
    //    }

    //    // GET: UserMasters/Delete/5
    //    public async Task<IActionResult> Delete(int? id)
    //    {
    //        if (id == null)
    //        {
    //            return NotFound();
    //        }

    //        var userMaster = await _context.UserMaster
    //            .FirstOrDefaultAsync(m => m.User_ID == id);
    //        if (userMaster == null)
    //        {
    //            return NotFound();
    //        }

    //        return View(userMaster);
    //    }

    //    // POST: UserMasters/Delete/5
    //    [HttpPost, ActionName("Delete")]
    //    [ValidateAntiForgeryToken]
    //    public async Task<IActionResult> DeleteConfirmed(int id)
    //    {
    //        var userMaster = await _context.UserMaster.FindAsync(id);
    //        _context.UserMaster.Remove(userMaster);
    //        await _context.SaveChangesAsync();
    //        return RedirectToAction(nameof(Index));
    //    }

    //    private bool UserMasterExists(int id)
    //    {
    //        return _context.UserMaster.Any(e => e.User_ID == id);
    //    }
    //}

    public class UserMastersController : Controller
    {
        private IuserMasterRepository _repository;
        private readonly IUserLogic _userLogic;
        public UserMastersController(IuserMasterRepository repository, IUserLogic userLogic)
        {
            _repository = repository;
            _userLogic = userLogic;
        }

        // GET: UserMasters
        public async Task<IActionResult> Index()
        {
            // return View(await _repository.GetAll());
            return View(await _userLogic.Users());
        }

        // GET: UserMasters/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userMaster = await _userLogic.GetById(id.Value);
            if (userMaster == null)
            {
                return NotFound();
            }

            return View(userMaster);
        }

        // GET: UserMasters/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: UserMasters/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Emp_id,LastName,FirstName,IsActive,PhoneNumber,EmailAddress,Joining_Date,Manager_id,Dept_id,Salary,Designation")] UserMaster userMaster)
        {
            if (ModelState.IsValid)
            {
                await _repository.Add(userMaster);
                return RedirectToAction(nameof(Index));
            }
            return View(userMaster);
        }

        // GET: UserMasters/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userMaster = await _repository.Get(id.Value);
            if (userMaster == null)
            {
                return NotFound();
            }
            return View(userMaster);
        }

        // POST: UserMasters/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("User_ID,LastName,FirstName,IsActive,EmailAddress,PasswordHash")] UserMaster userMaster)
        {
            if (id != userMaster.User_ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _repository.Update(userMaster);
                }
                catch (DbUpdateConcurrencyException)
                {

                }
                return RedirectToAction(nameof(Index));
            }
            return View(userMaster);
        }

        // GET: UserMasters/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userMaster = await _repository.Get(id.Value);
            if (userMaster == null)
            {
                return NotFound();
            }

            return View(userMaster);
        }

        // POST: UserMasters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _repository.Delete(id);
            return RedirectToAction(nameof(Index));
        }


    }
}
