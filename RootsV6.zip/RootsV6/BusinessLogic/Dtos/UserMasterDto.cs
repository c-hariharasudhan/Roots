﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic.Dtos
{
    public class UserMasterDto
    {
        public int User_ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IsActive { get; set; }
        public string PasswordHash { get; set; }
        public string EmailAddress { get; set; }
    }
}
