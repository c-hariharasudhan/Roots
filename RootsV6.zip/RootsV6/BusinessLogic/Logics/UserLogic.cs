﻿using AutoMapper;
using BusinessLogic.Dtos;
using DataLayer.Repository;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BusinessLogic.Logics
{
    public class UserLogic : IUserLogic
    {
        private IuserMasterRepository _repository;
        private readonly IMapper _mapper;

        public UserLogic(IuserMasterRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<UserMasterDto> GetById(int value)
        {
            var user = await _repository.Get(value);
            return _mapper.Map<UserMasterDto>(user);            
        }

        public async Task<IEnumerable<UserMasterDto>> Users()
        {
            var entity = await _repository.GetAll();
            return _mapper.Map<List<UserMasterDto>>(entity);
        }
    }
}
