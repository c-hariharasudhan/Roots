﻿using BusinessLogic.Dtos;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Logics
{
    public interface IUserLogic
    {
        Task<UserMasterDto> GetById(int value);
        Task<IEnumerable<UserMasterDto>> Users();
    }
}
