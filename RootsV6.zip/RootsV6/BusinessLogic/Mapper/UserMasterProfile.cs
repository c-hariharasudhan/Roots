﻿using AutoMapper;
using BusinessLogic.Dtos;
using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic.Mapper
{
    public class UserMasterProfile : Profile
    {
        public UserMasterProfile()
        {
            CreateMap<UserMaster, UserMasterDto>().ReverseMap();
        }
    }
}
