import React, { useState } from 'react';
import axios from 'axios';
import { Navigate } from 'react-router-dom';
const Login = props => {
  const username = useFormInput('');
  const password = useFormInput('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  // const history = useHistory();
  // handle button click of login form
  const handleLogin = () => {
    console.log("1");
    setError(null);
    setLoading(true);
    axios.post('https://localhost:7173/api/UserMaster', { User_ID: username.value, PasswordHash: password.value }).then(response => {
        console.log(response.data);
        if(response.data == true)
        {
            <Navigate to="/dashboard" />
            // this.props.history.push("/dashboard");
        }
    
    }).catch(error => {
        console.log(error)
      setLoading(false);
      if (error.response === 401) 
      setError(error.message);
      else setError("Something went wrong. Please try again later.");
    });
  }

  return (
    <div>
      Login<br /><br />
      <div>
        Username<br />
        <input type="text" {...username} autoComplete="new-password" />
      </div>
      <div style={{ marginTop: 10 }}>
        Password<br />
        <input type="password" {...password} autoComplete="new-password" />
      </div>
      {error && <><small style={{ color: 'red' }}>{error}</small><br /></>}<br />
      <input type="button" value={loading ? 'Loading...' : 'Login'} onClick={handleLogin} disabled={loading} /><br />
    </div>
  );
}

const useFormInput = initialValue => {
  const [value, setValue] = useState(initialValue);

  const handleChange = e => {
    setValue(e.target.value);
  }
  return {
    value,
    onChange: handleChange
  }
}

export default Login;